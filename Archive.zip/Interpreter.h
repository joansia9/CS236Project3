#ifndef PROJECT_1_INTERPRETER_H
#define PROJECT_1_INTERPRETER_H

#include "Header.h"
#include "Database.h"
#include "datalogProgram.h"
class Interpreter{
private:
    DatalogProgram program;
    Database database;
public:
    //constructor
    Interpreter(DatalogProgram program) : program(program) {}

    void run(){
        //cout << "will run Interpret_Schemes(); " << endl;
        Interpret_Schemes();
        //cout << "will run Interpret_Facts(); " << endl;
        Interpret_Facts();
        //cout << "will run Interpret_Queries(); " << endl;
        Interpret_Queries();
    }

    void Interpret_Schemes(){
        //takes care of headers
        //goes through columns
        for (Predicate scheme : program.Get_Schemes()) { //go through
            Header header; //creates new header

            for (Parameter p : scheme.Get_Parameters()) {
                header.Add_Header(p.Get_ID());
            }

            database.Add_Relation(scheme.Get_ID(), header);
        }
    }

    void Interpret_Facts() {
        //takes care of rows
        //goes through rows
        for (Predicate fact : program.Get_Facts()) {
            Tuple tuple;

            for (Parameter p : fact.Get_Parameters()) {
                tuple.Add_TupleValue(p.Get_ID());
            }

            database.Add_Tuple(fact.Get_ID(), tuple);
        }
    }

    void Interpret_Queries() {
        for (Predicate query : program.Get_Queries()) {
            cout << query.toString() << "?";
            Relation result = Interpret_Predicate(query);
            if (result.Get_Size() == 0) {
                cout << " " << "No" << std::endl;
            } else {
                cout << " " << "Yes(" << result.Get_Size() << ")" << std::endl;
            }

            cout << result.toString();
        }
    }

    Relation Interpret_Predicate (Predicate predicate) {
        Relation output = database.Get_Relation(predicate.Get_ID());
        map<string, unsigned int> seen;
        vector<int> uniqueIndex;
        vector<string> uniqueValues;
        unsigned int col = 0;

        for (Parameter parameter : predicate.Get_Parameters()) { //goes through each parameter
            string val = parameter.Get_ID();

            if (parameter.isConstant()) { //if the first parameter is a '
                output = output.select(col, parameter.Get_ID());    // select type 1 (int, value)
            } else {
                // seenBefore()
                if (seen.find(val) != seen.end()) {
                    output = output.select(col, seen.at(val));   // select type 2 (int, int)
                    // mark it as seen
                } else {
                    seen.insert({val, col});
                    uniqueIndex.push_back(col);
                    uniqueValues.push_back(val);
                }
            }
            col++;
        }

        // project
        output = output.project(uniqueIndex);

        // rename
        output = output.rename(uniqueValues);

        return output;
    }


};
#endif //PROJECT_1_INTERPRETER_H
