#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <set>

#include "Header.h"
#include "Tuple.h"

using namespace std;

#ifndef PROJECT_1_RELATION_H
#define PROJECT_1_RELATION_H
class Relation{
private:
    string name;
    Header header;
    set<Tuple> tuples;
public:
    //constructors
    Relation() = default;
    Relation(string name, Header header) : name(name), header(header) {}

    //getters
    string Get_Name() {
        return name;
    }
    int Get_Size() {
        return tuples.size();
    }

    //setters
    void Set_Tuples(set<Tuple> tuples) {
        this->tuples = tuples;
    }

    //adders
    void Add_Tuple(Tuple t) {
        tuples.insert(t);
    }

    //print function
    string toString() {
        stringstream o;
        for (Tuple t : tuples) {
            if (t.size() > 0) {
                o << " " << t.toString(header) << std::endl;
            }
        }

        return o.str();
    }

    Relation select(int position, string value) {
        //purpose: finds all the tuples that have a constant value in a certain column
        //parameter: takes 2 parameters -> a position and value
        //result: different number of rows
            // the given position would need to have a value equal to the given value for that tuple

        Relation output(name, header); //create an output with name and header copied over from input

        for (Tuple tuple : tuples) { //go through each row...
            if (tuple.Get_TupleValue(position) == value) { //if the tuple value = the value we want...
                output.Add_Tuple(tuple); //add the tuple to the output...
            }
        }
        return output; //returns a relation with different amount of rows!
    }

    Relation select(int position1, int position2) {
        //purpose: finds all the tuples that have the same value in 2 different columns
        //as long as both columns have the same value
        //parameter: takes 2 parameters: both positions
        //result: different number of rows
        // the 2 positions in a tuple would need to have equal values

        //cout << "in select function" << endl;

        Relation output(name, header); //create an output with name and header copied over from input

        //check: if the columns are in bounds
        if (position1 >= header.size() || position2 >= header.size()){ //if the position is greater or equal to size
            throw "out of bound"; //it is out of bound
        }

        for (Tuple tuple : tuples) { //go through each row
            if (tuple.Get_TupleValue(position1) == tuple.Get_TupleValue(position2)) { //if the tuple values are the same in both positions
                output.Add_Tuple(tuple); //add the tuple to the relation
            }
        }

        return output; //returns a new relation (ex) X='a' Y = 'a'
    }

    Relation project(vector<int> columnsToProject) {
        //purpose: changes the number and order of columns in a relation
        //result: either the same number or fewer columns
        //function: changes the header and all tuples in the relation
        //parameter: list of positions of the columns that should be included in the result (columns to be kept)

        Header new_Header; //create a new Header

        // Update columnNames with the selcted columns (passed in the function)
        for (auto i : columnsToProject) { //loop through selected columns to project
            new_Header.Add_Header(header.Find_Header(i)); //add header
        }

        Relation output(name, new_Header);

        // Update rows at the selcted columns (passed in the function)
        for (auto tuple : tuples) { //go through rows
            Tuple new_Tuple; //create a new tuple

            for (auto i : columnsToProject) {
                new_Tuple.Add_TupleValue(tuple.Get_TupleValue(i)); //add tuple
            }

            output.Add_Tuple(new_Tuple); //add tuple to relation
        }

        return output;
    }

    Relation rename(vector<string> header) {
        //purpose: changes the header of the relation
        //result: same tuples as the original (and columns and rows should not be changed)
        //parameter: position, and new name
        //function: replacing the entire list of attributes is easier and avoids issues with name conflicts

        Header new_header(header); //assigns input as a new header

        Relation output(name, new_header); //assign output to have the prev name and NEW header from input

        output.Set_Tuples(tuples); //copies over previous tuples

        return output;
    }

};
#endif //PROJECT_1_RELATION_H
